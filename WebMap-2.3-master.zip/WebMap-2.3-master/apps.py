from django.apps import AppConfig


class NmapreportConfig(AppConfig):
    name = 'nmapreport'
