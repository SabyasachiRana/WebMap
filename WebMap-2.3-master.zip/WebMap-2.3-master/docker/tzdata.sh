#!/bin/bash

unset DEBIAN_FRONTEND
dpkg-reconfigure tzdata
